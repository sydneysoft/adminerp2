-- MySQL dump 10.19  Distrib 10.3.37-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: tv
-- ------------------------------------------------------
-- Server version	10.3.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numero_documento` varchar(100) DEFAULT NULL,
  `correo` varchar(250) DEFAULT NULL,
  `clave` text DEFAULT NULL,
  `nombre` text DEFAULT NULL,
  `celular` varchar(255) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `ciudad` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `rol` varchar(200) DEFAULT NULL,
  `reg_date` datetime DEFAULT current_timestamp(),
  `ultima_conexion` datetime DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `tipo_documento` varchar(255) DEFAULT NULL,
  `pais` varchar(255) DEFAULT 'PE',
  `cod_recuperacion` varchar(255) DEFAULT NULL,
  `date_recuperacion` datetime DEFAULT NULL,
  `foto` text DEFAULT 'https://app.cdnstabletransit.net/images/avatar-whiteback.png',
  `apellido` varchar(255) DEFAULT 'Ninguno Ingresado',
  `modulos` text DEFAULT NULL,
  `codigo` varchar(50) DEFAULT NULL,
  `horamodulo` int(11) DEFAULT NULL,
  `horamodulovirtual` int(11) DEFAULT NULL,
  `id_especialidad` int(11) DEFAULT NULL,
  `numero_empresa` varchar(255) DEFAULT NULL,
  `id_referido` int(11) DEFAULT NULL,
  `id_tipopago` int(11) DEFAULT NULL,
  `id_membresia` int(11) DEFAULT NULL,
  `token` varchar(50) DEFAULT NULL,
  `device` varchar(255) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `platform` varchar(255) DEFAULT NULL,
  `session_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (68,'1111111','admin@tiendavirtual.com','$2b$05$EooM13jY3FaseNCyYYZD5OXHijcfra72yS4aBsfih8ncpJI587yum','admin',NULL,NULL,NULL,NULL,'superadmin','2022-12-19 13:28:18','2022-12-30 11:45:27','','DNI','PE',NULL,NULL,'https://app.cdnstabletransit.net/images/avatar-whiteback.png','Ninguno Ingresado',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Escritorio','Chrome 108','Win32','online'),(75,'5566621','empresa1@test.com','$2b$05$rXAgO4Lnxhk8WZV6t6Y0u.N.YpIYWAReixheuxcpUpOHckHOdJayu','Empresa 1',NULL,NULL,NULL,NULL,'empresa','2022-12-20 13:03:10','2023-01-04 08:50:18','','RUC','PE',NULL,NULL,'https://app.cdnstabletransit.net/images/avatar-whiteback.png','Ninguno Ingresado',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Escritorio','Chrome 108','Win32','online');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-04  8:54:53

-- MySQL dump 10.19  Distrib 10.3.37-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: tv
-- ------------------------------------------------------
-- Server version	10.3.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `portada_pages`
--

DROP TABLE IF EXISTS `portada_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `portada_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` varchar(45) DEFAULT '0',
  `nombre` varchar(255) DEFAULT NULL,
  `imagen` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portada_pages`
--

LOCK TABLES `portada_pages` WRITE;
/*!40000 ALTER TABLE `portada_pages` DISABLE KEYS */;
INSERT INTO `portada_pages` VALUES (1,'0','Busqueda','https://dox4euoyzny9u.cloudfront.net/images/smspubli/website/lanzamiento.jpg','2021-06-14 15:41:30'),(2,'0','Oferta','https://www.sistemaimpulsa.com/blog/wp-content/uploads/2019/02/apps-105107-696x541.jpg','2021-06-14 15:41:30'),(3,'0','Novedades','https://dox4euoyzny9u.cloudfront.net/images/smspubli/website/lanzamiento.jpg','2021-06-14 15:41:39'),(10,'75','Busqueda','http://groundandco.com.au/wp-content/plugins/uix-page-builder/includes/uixpbform/images/default-cover-6.jpg','2022-12-22 11:25:16'),(11,'75','Oferta','http://groundandco.com.au/wp-content/plugins/uix-page-builder/includes/uixpbform/images/default-cover-6.jpg','2022-12-22 11:25:16'),(12,'75','Novedades','http://groundandco.com.au/wp-content/plugins/uix-page-builder/includes/uixpbform/images/default-cover-6.jpg','2022-12-22 11:25:16'),(13,'29','Busqueda','https://blog.dinterweb.com/hubfs/Imported_Blog_Media/38060627_ml-e1482765993493.jpg','2023-01-04 11:14:49'),(14,'29','Oferta','http://groundandco.com.au/wp-content/plugins/uix-page-builder/includes/uixpbform/images/default-cover-6.jpg','2023-01-04 11:14:49'),(15,'29','Novedades','http://groundandco.com.au/wp-content/plugins/uix-page-builder/includes/uixpbform/images/default-cover-6.jpg','2023-01-04 11:14:49');
/*!40000 ALTER TABLE `portada_pages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-04  8:54:53
